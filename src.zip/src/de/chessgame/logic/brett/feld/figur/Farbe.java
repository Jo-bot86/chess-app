package de.chessgame.logic.brett.feld.figur;

/**
 * Repraesentiert die Farbe einer Figur
 * @author Josef Weldemariam
 *
 */
public enum Farbe {
	BLACK, WHITE
}
